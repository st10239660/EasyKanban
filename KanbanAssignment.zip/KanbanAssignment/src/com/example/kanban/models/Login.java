package com.example.kanban.models;

import com.example.kanban.interfaces.ILogin;

public class Login implements ILogin {

    String username;
    String firstName;
    String lastName;
    String password;

    public Login(String username, String firstName, String lastName, String password) {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
    }

    @Override
    public Boolean checkUserName() { return username.contains("_") && username.length() <= 5; }

    @Override
    public Boolean checkPasswordComplexity() {
        /*
        * password should be:
        * 1. at least 8 characters long
        * 2. contain a capital letter
        * 3. contain a number
        * 4. contain a special char
        * */

        char ch;
        boolean capitalFlag = false;
        boolean numberFlag = false;
        boolean specialCharFlag = false;

        if (password.length() < 8) {
            return false;
        }
        else {
            for (int index = 0; index < password.length(); index++) {
                ch = password.charAt(index);

                if (Character.isUpperCase(ch)) {
                    capitalFlag = true;
                }

                if (Character.isDigit(ch)) {
                    numberFlag = true;
                }

                if (!Character.isLetter(ch)) {
                    specialCharFlag = true;
                }

                if (capitalFlag && numberFlag && specialCharFlag) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public String registerUser() {
        /*
         * This method returns the necessary registration message indicating:
         * 1. username is incorrectly formatted
         * 2. password does not meet requirements
         * 3. the above conditions have been met and the user has been registered successfully
         * */
        var isValidUsername = checkUserName();
        var isValidPassword = checkPasswordComplexity();

        String message;

        if (isValidPassword && isValidUsername) {
            message = "Username and Password successfully captured.";
        }
        else if (!isValidUsername) {
            message = "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";

        }
        else {
            message = "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character";
        }

        return message;
    }

    @Override
    public Boolean loginUser(String loginUsername, String loginPassword) {
        return username.equals(loginUsername) && password.equals(loginPassword);
    }

    @Override
    public String returnLoginStatus(boolean isLoggedIn) {
        /*
         * This does not make sense as to why I should have this method.
         *
         * */
        String message;
        if (isLoggedIn) {
            message = "Welcome " + firstName + " " + lastName + ", " + "it is great to see you again.";
        }
        else {
            message = "Username or password incorrect, please try again.";
        }
        return message;
    }
}
