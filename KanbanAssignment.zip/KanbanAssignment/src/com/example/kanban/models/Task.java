package com.example.kanban.models;

import com.example.kanban.interfaces.ITask;

import java.util.ArrayList;
import java.util.List;

public class Task implements ITask {

    public String taskName;
    public int taskNumber = 0;
    public String taskDescription;
    public String developerDetails;
    public String taskID;
    public int taskDuration;

    protected List<Task> tasks = new ArrayList<>();

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public String getDeveloperDetails() {
        return developerDetails;
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public Boolean createTask() {
        var name = getTaskName();
        var desc = getTaskDescription();
        var developer = getDeveloperDetails();
        var duration = getTaskDuration();

        var isValid = checkTaskDescription();

        if (!isValid) {
            return false;
        }
        else {
            var task = new Task(name, desc, developer, duration);
            task.taskID = createTaskID(taskNumber);

            tasks.add(task);

            taskNumber++;

            return true;
        }
    }

    @Override
    public Boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    @Override
    public String createTaskID(int taskNumber) {

        var getFirstTwoLetters = taskName.substring(0, 2).toUpperCase();
        var getLastThreeLetters = developerDetails.substring(developerDetails.length() - 3).toUpperCase();

        return getFirstTwoLetters.concat(":").concat(String.valueOf(taskNumber)).concat(":").concat(getLastThreeLetters);
    }

    @Override
    public String printTaskDetails() {
        return null;
    }

    @Override
    public int returnTotalHours() {
        return 0;
    }
}
