package com.example.kanban.models;

public class Example {

    public static void main(String[] args) {

    }
}
