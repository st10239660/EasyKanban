package com.example.kanban;

import com.example.kanban.models.Task;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TaskForm extends JFrame implements ActionListener {

    private static JFrame frame, addTaskFrame, addTaskDetailsFrame;
    private static JPanel panel, addTaskPanel, addTaskDetailsPanel;
    private static JTextField optionTextField, numberOfTasks, taskName, developerDetails, taskDuration, taskDescription;

    public void WelcomeScreen() {
        frame = new JFrame();
        panel = new JPanel();

        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);

        Menu();

        JButton submitBtn = new JButton("Submit");
        submitBtn.setBounds(10, 130, 80, 25);
        submitBtn.addActionListener(new TaskForm());
        panel.add(submitBtn);

        frame.setVisible(true);
    }

    public static void Menu() {
        JLabel welcomeLabel = new JLabel("Welcome to EasyKanban");
        welcomeLabel.setBounds(10, 10, frame.getWidth(), 25);
        panel.add(welcomeLabel);

        JLabel option1 = new JLabel("Option 1) Add tasks");
        option1.setBounds(10, 30, frame.getWidth(), 25);
        panel.add(option1);

        JLabel option2 = new JLabel("Option 2) Show report - coming soon.");
        option2.setBounds(10, 50, frame.getWidth(), 25);
        panel.add(option2);

        JLabel option3 = new JLabel("Option 3) Quit");
        option3.setBounds(10, 70, frame.getWidth(), 25);
        panel.add(option3);

        optionTextField = new JTextField(20);
        optionTextField.setBounds(10, 100, 165, 25);
        panel.add(optionTextField);
    }

    public static void AddTask() {
        addTaskFrame = new JFrame();
        addTaskPanel = new JPanel();
        addTaskFrame.setSize(400, 300);
        addTaskFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addTaskFrame.add(addTaskPanel);

        // first ask how many they would like to enter
        // we need to enter the task name, description, developer details, task duration

        JLabel label = new JLabel("How many tasks would you like to add?");
        label.setBounds(10, 20, addTaskFrame.getWidth(), 25);
        addTaskPanel.add(label);

        numberOfTasks = new JTextField(20);
        numberOfTasks.setBounds(10, 30, 80, 25);
        addTaskPanel.add(numberOfTasks);

        JButton taskBtn = new JButton("Ok");
        taskBtn.setBounds(10, 50, 80, 25);
        taskBtn.addActionListener(new TaskForm());
        addTaskPanel.add(taskBtn);

        addTaskFrame.setVisible(true);

    }

    public static void AddTaskDetails() {
        addTaskDetailsFrame = new JFrame();
        addTaskDetailsPanel = new JPanel();

        addTaskDetailsFrame.setSize(400, 300);
        addTaskDetailsFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addTaskDetailsFrame.add(addTaskDetailsPanel);

        var width = addTaskDetailsFrame.getWidth();
        var height = addTaskDetailsFrame.getHeight();

        JLabel taskNameLabel = new JLabel("Task name:");
        taskNameLabel.setBounds(10, 40, width, 25);
        addTaskDetailsPanel.add(taskNameLabel);

        taskName = new JTextField(20);
        taskName.setBounds(100, 40, 165, 25 );
        addTaskDetailsPanel.add(taskName);

        JLabel descLabel = new JLabel("Task description:");
        descLabel.setBounds(10, 80, width, 25);
        addTaskDetailsPanel.add(descLabel);

        taskDescription = new JTextField(20);
        taskDescription.setBounds(100, 80, 165, height / 2);
        addTaskDetailsPanel.add(taskDescription);

        JLabel devDetails = new JLabel("Developer details:");
        devDetails.setBounds(10, 120, width, 25);
        addTaskDetailsPanel.add(devDetails);

        developerDetails = new JTextField(20);
        developerDetails.setBounds(100, 120, 165, 25);
        addTaskDetailsPanel.add(developerDetails);

        JLabel duration = new JLabel("Task duration:");
        duration.setBounds(10, 160, width, 25);
        addTaskDetailsPanel.add(duration);

        taskDuration = new JTextField(20);
        taskDuration.setBounds(100, 160, 165, 25);
        addTaskDetailsPanel.add(taskDuration);

        JButton addTaskBtn = new JButton("Add");
        addTaskBtn.addActionListener(new TaskForm());
        addTaskBtn.setBounds(10, 200, 80, 25);
        addTaskDetailsPanel.add(addTaskBtn);


        addTaskDetailsFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        var option = optionTextField.getText().trim();
        var btnEvent = e.getActionCommand();

        if (btnEvent.equals("Ok")) {
            var taskNumber = numberOfTasks.getText().trim();
            var tasks = Integer.parseInt(taskNumber);
            int iterations = 1;

            AddTaskDetails();

            addTaskFrame.dispose();
        }
        else if (btnEvent.equals("Add")) {
            var name = taskName.getText().trim();
            var desc = taskDescription.getText().trim();
            var devDetails = developerDetails.getText().trim();
            var duration = taskDuration.getText().trim();

            var dur = Integer.parseInt(duration);

            Task task = new Task(name, desc, devDetails, dur);

            task.createTask();
        }
        else if (btnEvent.equals("Submit")){
            switch (option) {
                case "1" -> AddTask();
                case "2" -> System.out.println("option 2");
                case "3" -> frame.dispose();
                default -> throw new IllegalStateException("Unexpected value: " + option);
            }
        }


    }
}
