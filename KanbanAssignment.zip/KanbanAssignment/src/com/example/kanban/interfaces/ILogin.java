package com.example.kanban.interfaces;

public interface ILogin {
    Boolean checkUserName();
    Boolean checkPasswordComplexity();
    String registerUser();
    Boolean loginUser(String username, String password);
    String returnLoginStatus(boolean isLoggedIn);
}
