package com.example.kanban.interfaces;

public interface ITask {
    Boolean checkTaskDescription();
    String createTaskID(int taskNumber);
    String printTaskDetails();
    int returnTotalHours();
}
