package com.example.kanban;

import com.example.kanban.models.Login;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main implements ActionListener {

    private static JFrame frame, loginFrame;
    private static JLabel usernameLabel;
    private static JLabel passwordLabel;
    private static JLabel registerErrorLabel;
    private static JLabel loginErrorLabel;
    private static JTextField usernameField, firstNameField, lastNameField, loginUsernameField;
    private static JPasswordField passwordField, loginPasswordField;

    public static void main(String[] args) {

        RegisterFrame();
//        new TaskForm().WelcomeScreen();
    }

    public static void LoginFrame() {
        loginFrame = new JFrame();
        JPanel loginPanel = new JPanel();
        loginFrame.setSize(400, 300);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        loginFrame.add(loginPanel);

        loginPanel.setLayout(null);

        JLabel loginLabel = new JLabel("Login");
        loginLabel.setBounds(10, 10, 80, 25);
        loginPanel.add(loginLabel);

        usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(10, 40, 80, 25);
        loginPanel.add(usernameLabel);

        loginUsernameField = new JTextField(20);
        loginUsernameField.setBounds(100, 40, 165, 25);
        loginPanel.add(loginUsernameField);

        passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 70, 80, 25);
        loginPanel.add(passwordLabel);

        loginPasswordField = new JPasswordField(20);
        loginPasswordField.setBounds(100, 70, 165, 25);
        loginPanel.add(loginPasswordField);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(10, 100, 80, 25);
        loginBtn.addActionListener(new Main());
        loginPanel.add(loginBtn);

        loginErrorLabel = new JLabel("");
        loginErrorLabel.setBounds(10, 120, loginFrame.getWidth(), 25);
        loginPanel.add(loginErrorLabel);

        loginFrame.setVisible(true);
    }

    public static void RegisterFrame() {
        frame = new JFrame();
        JPanel panel = new JPanel();

        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);

        panel.setLayout(null);

        // username label and text field
        usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(10, 20, 80, 25);
        panel.add(usernameLabel);

        usernameField = new JTextField(20);
        usernameField.setBounds(100, 20, 165, 25);
        panel.add(usernameField);

        // first name label and text field
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(10, 60, 80, 25);
        panel.add(firstNameLabel);

        firstNameField = new JTextField(20);
        firstNameField.setBounds(100, 60, 165, 25);
        panel.add(firstNameField);

        // last name label and text field
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(10, 100, 80, 25);
        panel.add(lastNameLabel);

        lastNameField = new JTextField(20);
        lastNameField.setBounds(100, 100, 165, 25);
        panel.add(lastNameField);

        // password label and text field
        passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 140, 80, 25);
        panel.add(passwordLabel);

        passwordField = new JPasswordField(20);
        passwordField.setBounds(100, 140, 165, 25);
        panel.add(passwordField);

        // button
        JButton registerBtn = new JButton("Register");
        registerBtn.setBounds(10, 200, 80, 25);
        registerBtn.addActionListener(new Main());
        panel.add(registerBtn);

        // error label
        registerErrorLabel = new JLabel("");
        registerErrorLabel.setBounds(10, 180, frame.getWidth(), 25);
        panel.add(registerErrorLabel);

        frame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        var button = e.getActionCommand();

        String username = usernameField.getText().trim();
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String password = String.valueOf(passwordField.getPassword()).trim();

        Login login = new Login(username, firstName, lastName, password);
        
        if(button.equals("Login")) {

            String loginUsername = loginUsernameField.getText().trim();
            String loginPassword = String.valueOf(loginPasswordField.getPassword()).trim();
            var isLoggedIn = login.loginUser(loginUsername, loginPassword);
            var message = login.returnLoginStatus(isLoggedIn);

            loginErrorLabel.setText(message);

            if (isLoggedIn) {
                // i'd like to display a new frame
                System.out.println("display new window");
                loginFrame.dispose();

                new TaskForm().WelcomeScreen();
            }
        }
        else {
            var response = login.registerUser();

            if (response.equals("Username and Password successfully captured.")) {
                frame.dispose();
                LoginFrame();
            }
            else {
                registerErrorLabel.setText(response);
            }
        }
    }
}
